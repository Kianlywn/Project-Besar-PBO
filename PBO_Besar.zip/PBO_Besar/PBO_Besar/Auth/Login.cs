﻿using PBO_Besar.Menu.Menu_Admin;
using PBO_BESAR.DataAccess;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PBO_Besar.Auth
{
    public partial class Login : Form
    {
        public Login()
        {
            InitializeComponent();
        }

        private void btnLogin_Click(object sender, EventArgs e)
        {
            string username = txtUsername.Text.Trim();
            string password = txtPassword.Text.Trim();

            // Validasi input
            if (string.IsNullOrEmpty(username) || string.IsNullOrEmpty(password))
            {
                MessageBox.Show("Username dan password harus diisi!");
                return;
            }

            // Parameterized query untuk mencegah SQL injection
            string query = "SELECT id, full_name, role FROM users WHERE username = @username AND password = @password";
            var parameters = new Dictionary<string, object>
    {
        { "@username", username },
        { "@password", password }
    };

            try
            {
                DataTable result = Database.ExecuteQuery(query, parameters);

                if (result.Rows.Count > 0)
                {
                    string role = result.Rows[0]["role"].ToString();
                    string fullName = result.Rows[0]["full_name"].ToString();
                    int userId = Convert.ToInt32(result.Rows[0]["id"]);

                    this.Hide(); // Sembunyikan form login

                    if (role == "admin")
                    {
                        MessageBox.Show($"Selamat datang Admin {fullName}");
                        MenuAdmin menuAdmin = new MenuAdmin(userId);
                        menuAdmin.FormClosed += (s, args) => this.Close();
                        menuAdmin.Show();
                    }
                    else
                    {
                        MessageBox.Show($"Selamat datang Kasir {fullName}");
                        //FormKasir kasirForm = new FormKasir(userId);
                        //kasirForm.FormClosed += (s, args) => this.Close();
                        //kasirForm.Show();
                    }
                }
                else
                {
                    MessageBox.Show("Username atau password salah.");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Terjadi error: {ex.Message}");
            }
        }
        private void btnRegis_Click_1(object sender, EventArgs e)
        {
            // Sembunyikan form login saat ini
            this.Hide();

            // Buat instance form register
            Register registerForm = new Register();
            registerForm.FormClosed += (s, args) =>
            {
                this.Show();
                txtUsername.Text = "";
                txtPassword.Text = "";
            };

            // Tampilkan form register
            registerForm.Show();
        }
    }
}
