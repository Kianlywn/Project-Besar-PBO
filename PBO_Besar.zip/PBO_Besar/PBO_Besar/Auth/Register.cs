﻿using PBO_BESAR.DataAccess;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PBO_Besar.Auth
{
    public partial class Register : Form
    {
        public Register()
        {
            InitializeComponent();
        }

        private void btnRegister_Click(object sender, EventArgs e)
        {
            string username = txtUsername.Text.Trim();
            string password = txtPassword.Text.Trim();
            string fullName = txtFullName.Text.Trim();

            if (username == "" || password == "" || fullName == "")
            {
                MessageBox.Show("Semua field wajib diisi!");
                return;
            }

            string checkQuery = $"SELECT * FROM users WHERE username = '{username}'";
            DataTable checkResult = Database.ExecuteQuery(checkQuery);
            if (checkResult.Rows.Count > 0)
            {
                MessageBox.Show("Username sudah digunakan.");
                return;
            }

            string insertQuery = $"INSERT INTO users (username, password, full_name, role) " +
                                 $"VALUES ('{username}', '{password}', '{fullName}', 'kasir')";

            try
            {
                Database.ExecuteNonQuery(insertQuery);
                MessageBox.Show("Registrasi berhasil!");
                this.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Gagal registrasi: " + ex.Message);
            }
        }
    }
}
