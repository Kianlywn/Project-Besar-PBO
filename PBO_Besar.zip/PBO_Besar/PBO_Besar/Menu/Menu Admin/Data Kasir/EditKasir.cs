﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PBO_Besar.Menu.Menu_Admin.Data_Kasir
{
    public partial class EditKasir: Form
    {
        public EditKasir()
        {
            InitializeComponent();
        }
    }
}
